﻿namespace JiffyBackend.API.Dto
{
    public class CreateActivityDto
    {
        public string Name { get; set; }
    }
}
