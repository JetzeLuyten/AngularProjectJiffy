﻿namespace JiffyBackend.API.Dto
{
    public class GetActivityDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
