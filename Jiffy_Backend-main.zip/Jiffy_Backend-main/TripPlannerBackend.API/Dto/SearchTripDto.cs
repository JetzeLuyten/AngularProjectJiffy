﻿namespace JiffyBackend.API.Dto
{
    public class SearchTripDto
    {
        public string Name { get; set; }
        public string? Destination { get; set; }
    }
}
