﻿using AutoMapper;
using JiffyBackend.API.Dto;
using JiffyBackend.DAL.Entity;

namespace JiffyBackend.API.Mapper
{
    public class AutoMapper : Profile
    {
        public AutoMapper()
        {
            CreateMap<GetTripDto, ServiceType>();
            CreateMap<CreateTripDto, ServiceType>();
            CreateMap<ServiceType, GetTripDto>();
                //.ForMember(dest => dest.Name, act => act.MapFrom(src => src.TripName));
            CreateMap<Service, GetActivityDto>();
            CreateMap<GetActivityDto, Service>();
            CreateMap<CreateActivityDto, Service>();
        }
    }
}
