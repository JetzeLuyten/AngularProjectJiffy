﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JiffyBackend.DAL.Entity
{
    public class Service
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public ServiceType Type { get; set; }
        public DateTime Time { get; set; }
        public string Description { get; set; }
        public bool Completed { get; set; }
        public string Author { get; set; }
        public DateTime PublishDate { get; set; }
    }
}
