﻿using JiffyBackend.DAL.Entity;

namespace JiffyBackend.DAL.Initializer
{
    public class DBInitializer
    {
        public static void Initialize(JiffyDbContext context)
        {
            context.Database.EnsureCreated();

            // Seed the Trips table with some dummy data
            if (!context.Trips.Any())
            {
                var trips = new ServiceType[]
                {
                new ServiceType {
                    Name = "Trip 1", Activities = new List<Service>()
                {
                    new Service(){Name="Activity 1"},
                    new Service(){Name="Activity 2"},
                    new Service(){Name="Activity 3"},
                    new Service(){Name="Activity 4"}
                }
                },
                new ServiceType { Name = "Trip 2" },
                new ServiceType { Name = "Trip 3" },
                new ServiceType { Name = "Trip 4" },
                new ServiceType { Name = "Trip 5" },
               };

                foreach (ServiceType t in trips)
                {
                    context.Trips.Add(t);
                }

                context.SaveChanges();
            }
        }
    }
}

