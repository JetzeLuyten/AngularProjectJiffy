﻿using Microsoft.EntityFrameworkCore;
using JiffyBackend.DAL.Entity;

namespace JiffyBackend.DAL
{
    public class JiffyDbContext : DbContext
    {
        public JiffyDbContext()
        {

        }

        public JiffyDbContext(DbContextOptions<JiffyDbContext> options) : base(options)
        {
        }
        public DbSet<ServiceType> Trips => Set<ServiceType>();
        public DbSet<Service> Activities => Set<Service>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ServiceType>()
               .HasMany(e => e.Activities)
               .WithOne(e => e.Trip)
               .HasForeignKey(e => e.TripId)
               .IsRequired();

            //Other side
            //modelBuilder.Entity<Activity>()
            //    .HasOne(e => e.Trip)
            //    .WithMany(e => e.Activities)
            //    .HasForeignKey(e => e.TripId)
            //    .IsRequired();

            modelBuilder.Entity<ServiceType>().ToTable("Trip");
            modelBuilder.Entity<Service>().ToTable("Activity");
        }
    }
}